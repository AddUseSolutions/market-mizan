# Market Mizan scraped dataset export

Generated from the live public API (`market-mizan-api.onrender.com`).

## Coverage

- **Listings:** full active catalog snapshot (**2,705** rows)
- **Scraping window:** `first_seen` **2026-04-16 → 2026-09-21** (~5 months since scraping started; not a full calendar 6 months yet)
- **Sources:** realethio.com (~1,730), ethiopiarealty.com (~900), just.property (~75)
- **Price history:** time series from `price_history` (**join on `property_id`**). Many listings only have a baseline or none yet — daily change tracking ramped up more recently.

## Files

| File | Description |
|------|-------------|
| `mmizan_dataset_YYYYMMDD.zip` | Everything below, ready to share |
| `mmizan_listings_YYYYMMDD.csv` | One row per active listing |
| `mmizan_listings_YYYYMMDD.json` | Same as CSV |
| `mmizan_price_history_YYYYMMDD.csv` | `property_id`, `price_etb`, `price_usd`, `recorded_at` |
| `mmizan_export_meta_YYYYMMDD.json` | Counts and date range |

## Listing columns (CSV)

`property_id`, `source_website`, `title`, `property_type`, `property_status`, `canonical_area`, location fields, beds/baths/size, `price_etb` / `price_usd`, FX, HMLO, `detail_url`, `image_count` / `image_1`, `first_seen` / `last_seen` / `scraped_at`, short `description`

## Notes

- Descriptions truncated to 500 chars
- Inactive / delisted listings are **not** included (public catalog only)
- Price-history API returns at most **50** snapshots per listing
- For a full DB dump including inactive rows, export from Render with `DATABASE_URL`
